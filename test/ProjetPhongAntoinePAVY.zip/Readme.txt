Contrôles : 

            Avancer               Haut       
                                          
               Z                   A
               ^                   ^
               |                   |
Gauche  Q <----+----> D  Droite    +
               |                   |       
               v                   v     
               S                   W     
                                          
            Reculer               Bas

Orientation de la caméra (yaw et pitch) : Curseur de la souris

Quitter : Escape